package com.example.friday

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class AssistantService : Service() {

    companion object {
        const val ACTION_START = "com.example.friday.START"
        const val ACTION_STOP = "com.example.friday.STOP"
        const val ACTION_TOGGLE_WAKE_WORD = "com.example.friday.TOGGLE_WAKE_WORD"

        const val BROADCAST_TRANSCRIPT = "com.example.friday.TRANSCRIPT"
        const val EXTRA_TEXT = "text"

        private const val CHANNEL_ID = "friday_channel"
        private const val NOTIF_ID = 1001
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var tts: FridayTts? = null
    private var wakeWordEnabled = true

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = broadcast("Слушаю, босс...")
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            broadcast("-")
            restartWithDelay(500)
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text == null) {
                restartWithDelay(300)
                return
            }
            broadcast(text)
            processCommand(text)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = FridayTts(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListening()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }

            ACTION_TOGGLE_WAKE_WORD -> {
                wakeWordEnabled = !wakeWordEnabled
                updateNotification(if (wakeWordEnabled) "Режим ожидания: ВКЛ" else "Режим ожидания: ВЫКЛ")
            }

            else -> {
                startForeground(NOTIF_ID, buildNotification("Слушаю, босс..."))
                startListening()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopListening()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "FRIDAY", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("FRIDAY")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun startListening() {
        if (listening || recognizer != null) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(listener)
        sr.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
        )
        recognizer = sr
        listening = true
        updateNotification("Слушаю, босс...")
    }

    private fun stopListening() {
        recognizer?.destroy()
        recognizer = null
        listening = false
    }

    private fun restartWithDelay(delayMs: Long) {
        handler.postDelayed({
            recognizer?.destroy()
            recognizer = null
            listening = false
            if (tts != null) startListening()
        }, delayMs)
    }

    private fun processCommand(raw: String) {
        val cmd = raw.lowercase().trim()

        val clean: String = if (wakeWordEnabled) {
            if (cmd.contains("пятница") || cmd.contains("фрайдей") || cmd.contains("friday")) {
                cmd.replace(Regex("пятница|фрайдей|friday"), "").trim()
            } else {
                ""
            }
        } else {
            cmd
        }

        if (clean.isEmpty()) {
            restartWithDelay(200)
            return
        }

        val reply = CommandProcessor.process(clean, this)
        broadcast(reply.text)
        tts?.speak(reply.text) {
            restartWithDelay(300)
        }
    }

    private fun broadcast(text: String) {
        val intent = Intent(BROADCAST_TRANSCRIPT).putExtra(EXTRA_TEXT, text)
        sendBroadcast(intent)
    }
}
