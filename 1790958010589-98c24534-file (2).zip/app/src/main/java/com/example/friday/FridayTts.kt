package com.example.friday

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Locale

class FridayTts(context: Context) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private val tts = TextToSpeech(context, this)
    private val handler = Handler(Looper.getMainLooper())
    private val pendingDone = HashMap<String, () -> Unit>()
    private var ready = false

    private val elevenKey: String = BuildConfig.ELEVENLABS_API_KEY
    private val elevenVoiceId: String = "EXAVITQu4vr4xnSDxMaL"

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return

        val lang = tts.setLanguage(Locale("ru", "RU"))
        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.getDefault())
        }

        tts.setPitch(1.05f)
        tts.setSpeechRate(0.92f)

        val voices = tts.voices ?: emptySet()
        val female = voices.firstOrNull {
            val n = it.name.lowercase()
            (n.contains("female") || n.contains("женск") || n.contains("elena") || n.contains("anna") || n.contains("milena")) &&
                    it.locale.language == "ru"
        }
        if (female != null) tts.voice = female

        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                pendingDone.remove(utteranceId)?.invoke()
            }
            @Deprecated("Required override")
            override fun onError(utteranceId: String?) {
                pendingDone.remove(utteranceId)?.invoke()
            }
        })

        ready = true
    }

    fun speak(text: String, onDone: () -> Unit = {}) {
        if (!ready) {
            handler.postDelayed({ speak(text, onDone) }, 200)
            return
        }
        if (elevenKey.isNotBlank()) speakViaElevenLabs(text, onDone) else speakLocal(text, onDone)
    }

    private fun speakLocal(text: String, onDone: () -> Unit) {
        val id = "u_${System.currentTimeMillis()}"
        pendingDone[id] = onDone
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun speakViaElevenLabs(text: String, onDone: () -> Unit) {
        val client = OkHttpClient()
        val body = JSONObject()
            .put("text", text)
            .put("model_id", "eleven_multilingual_v2")
            .toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/$elevenVoiceId?output_format=mp3_44100_128")
            .header("xi-api-key", elevenKey)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("FridayTts", "ElevenLabs недоступен: ${e.message}")
                handler.post { speakLocal(text, onDone) }
            }

            override fun onResponse(call: Call, response: Response) {
                val bytes = response.use { it.body?.bytes() }
                if (response.isSuccessful && bytes != null) {
                    handler.post { playMp3(bytes, onDone) }
                } else {
                    Log.e("FridayTts", "ElevenLabs HTTP ${response.code}")
                    handler.post { speakLocal(text, onDone) }
                }
            }
        })
    }

    private fun playMp3(bytes: ByteArray, onDone: () -> Unit) {
        val file = File(appContext.cacheDir, "friday_${System.currentTimeMillis()}.mp3")
        file.writeBytes(bytes)
        val player = MediaPlayer()
        player.setDataSource(file.absolutePath)
        player.setOnCompletionListener {
            it.release()
            file.delete()
            handler.post(onDone)
        }
        player.setOnErrorListener { mp, _, _ ->
            mp.release()
            file.delete()
            handler.post(onDone)
            true
        }
        player.prepare()
        player.start()
    }

    fun shutdown() {
        ready = false
        tts.stop()
        tts.shutdown()
    }
}
