package com.example.friday

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CommandProcessor {

    data class Reply(val text: String)

    private val appAliases = mapOf(
        "ютуб" to "com.google.android.youtube",
        "youtube" to "com.google.android.youtube",
        "телефон" to "com.android.dialer",
        "контакты" to "com.google.android.contacts",
        "карты" to "com.google.android.apps.maps",
        "браузер" to "com.android.chrome",
        "хром" to "com.android.chrome",
        "калькулятор" to "com.google.android.calculator",
        "настройки" to "com.android.settings",
        "галерея" to "com.google.android.apps.photos",
        "фото" to "com.google.android.apps.photos",
        "плей маркет" to "com.android.vending",
        "маркет" to "com.android.vending",
        "телеграм" to "org.telegram.messenger",
        "вотсап" to "com.whatsapp",
        "вконтакте" to "com.vkontakte.android",
        "вк" to "com.vkontakte.android",
        "инстаграм" to "com.instagram.android",
        "спотифай" to "com.spotify.music"
    )

    fun process(raw: String, context: Context): Reply {
        val t = raw.lowercase().trim()
        return when {
            t.contains("позвони") || t.contains("набери") -> handleCall(t, context)
            t.contains("открой") || t.contains("запусти") -> handleOpen(t, context)
            t.contains("фото") || t.contains("снимок") || t.contains("сфоткай") -> handlePhoto(context)
            t.contains("сколько времени") || t.contains("который час") || t.contains("время") -> handleTime()
            t.contains("какая дата") || t.contains("какое число") || t.contains("дата") -> handleDate()
            t.contains("привет") || t.contains("здравствуй") -> Reply("Приветствую, сэр. FRIDAY на связи.")
            t.contains("как дела") || t.contains("как ты") -> Reply("Все системы в норме, босс. Готова к работе.")
            t.contains("спасибо") -> Reply("Рада служить, босс.")
            t.contains("выключись") || t.contains("стоп") || t.contains("выключить") ->
                Reply("Отключаюсь. До следующего вызова, сэр.")
            else -> Reply("Команда не распознана. Попробуйте: открыть ютуб, сколько времени, позвони маме.")
        }
    }

    private fun handleOpen(t: String, context: Context): Reply {
        for ((alias, pkg) in appAliases) {
            if (t.contains(alias)) {
                val intent = context.packageManager.getLeanbackLaunchIntentForPackage(pkg)
                    ?: context.packageManager.getLaunchIntentForPackage(pkg)
                return if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    Reply("Открываю $alias.")
                } else Reply("Не нашла $alias на устройстве.")
            }
        }
        return Reply("Не поняла, какое приложение открыть.")
    }

    private fun handleCall(t: String, context: Context): Reply {
        val name = t.replace(Regex("позвони|набери|пожалуйста|пж|будь добра"), "").trim()
        if (name.isEmpty()) return Reply("Кому звонить, босс?")
        val number = findContactNumber(context, name) ?: return Reply("Не нашла контакт $name.")
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            Reply("Звоню $name.")
        } catch (e: Exception) {
            Reply("Не удалось позвонить. Дайте разрешение на звонки.")
        }
    }

    private fun handlePhoto(context: Context): Reply {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            Reply("Снимаю фото, босс.")
        } catch (e: Exception) {
            Reply("Камера недоступна.")
        }
    }

    private fun handleTime(): Reply {
        val sdf = SimpleDateFormat("HH:mm", Locale("ru", "RU"))
        return Reply("Сейчас " + sdf.format(Date()) + ", босс.")
    }

    private fun handleDate(): Reply {
        val sdf = SimpleDateFormat("d MMMM, EEEE", Locale("ru", "RU"))
        return Reply("Сегодня " + sdf.format(Date()) + ".")
    }

    private fun findContactNumber(context: Context, query: String): String? {
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$query%")
        resolver.query(uri, projection, selection, args, null)?.use { c ->
            while (c.moveToNext()) {
                return c.getString(0)
            }
        }
        return null
    }
}
