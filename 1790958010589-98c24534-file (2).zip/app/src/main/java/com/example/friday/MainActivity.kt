package com.example.friday

import android.Manifest
import android.animation.ObjectAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.friday.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var serviceRunning = false
    private var pulse: ObjectAnimator? = null

    private val permissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.FOREGROUND_SERVICE_MICROPHONE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val denied = result.filterValues { !it }.keys
            if (denied.isEmpty()) {
                toast("Разрешения получены, босс.")
            } else {
                toast("Нужны разрешения: $denied")
            }
            refreshUi()
        }

    private val transcriptReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(AssistantService.EXTRA_TEXT) ?: return
            binding.status.text = "СЛУШАЮ"
            appendLog(text)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPermissions.setOnClickListener { permissionLauncher.launch(permissions.toTypedArray()) }

        binding.btnToggle.setOnClickListener {
            if (serviceRunning) {
                stopService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    toast("Сначала дайте доступ к микрофону.")
                    permissionLauncher.launch(permissions.toTypedArray())
                    return@setOnClickListener
                }
                startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_START))
            }
        }

        binding.btnWake.setOnClickListener {
            startService(Intent(this, AssistantService::class.java)
                .setAction(AssistantService.ACTION_TOGGLE_WAKE_WORD))
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(AssistantService.BROADCAST_TRANSCRIPT)
        registerReceiver(transcriptReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(transcriptReceiver) } catch (_: Exception) {}
    }

    private fun refreshUi() {
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        if (micOk) startPulse() else stopPulse()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun startPulse() {
        if (pulse != null) return
        pulse = ObjectAnimator.ofFloat(binding.core, "scaleX", 1f, 1.12f).apply {
            duration = 900
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            interpolator = DecelerateInterpolator()
        }
        pulse?.start()
        ObjectAnimator.ofFloat(binding.core, "scaleY", 1f, 1.12f).apply {
            duration = 900
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            interpolator = DecelerateInterpolator()
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        binding.core.animate().scaleX(1f).scaleY(1f).setDuration(300).start()
    }

    private fun appendLog(text: String) {
        binding.log.append("\n> " + text)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
