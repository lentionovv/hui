plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val elevenLabsKey: String = (project.findProperty("elevenlabs.key") as String?) ?: ""

android {
    namespace = "com.example.friday"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.friday"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        buildConfigField("String", "ELEVENLABS_API_KEY", "\"$elevenLabsKey\"")
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
